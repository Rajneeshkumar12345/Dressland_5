export default  {
    ADMIN: 'ADMIN',
    USER: 'USER' ,
    VENDOR: 'VENDOR',
    CENTOR: 'CENTOR'  
}