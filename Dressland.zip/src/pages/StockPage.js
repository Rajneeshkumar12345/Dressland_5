// import React from 'react'

// function StockPage() {
//   return (
//     <>

//     <h1>This is Stack Page</h1>
//     <div className="container">
//     <a href="#" className="list-group-item list-group-item-action " aria-current="true">
//     <div className="d-flex w-100 justify-content-between">
//       <h5 className="mb-1 text-center">Item 1</h5>
//       <small><button className='btn btn-danger'>Delete</button></small>
//     </div>
//     <div className="some">
//         <button className='btn btn-success'>Add</button>
//         <button className='btn btn-dark ms-2'>Update</button>
//         <button className='btn btn-info ms-2'>Read More</button>
//     </div>
//   </a>
 
//   <a href="#" className="list-group-item list-group-item-action mt-5">
//     <div className="d-flex w-100 justify-content-between">
//       <h5 className="mb-1 text-center">Item 2</h5>
//       <small><button className='btn btn-danger'>Delete</button></small>
//     </div>
//     <div className="some">
//         <button className='btn btn-success'>Add</button>
//         <button className='btn btn-dark ms-2'>Update</button>
//         <button className='btn btn-info ms-2'>Read More</button>
//     </div>
//   </a>
//   <a href="#" className="list-group-item list-group-item-action mt-5">
//     <div className="d-flex w-100 justify-content-between">
//       <h5 className="mb-1 text-center">Item 3</h5>
//       <small><button className='btn btn-danger'>Delete</button></small>
//     </div>
//     <div className="some">
//         <button className='btn btn-success'>Add</button>
//         <button className='btn btn-dark ms-2'>Update</button>
//         <button className='btn btn-info ms-2'>Read More</button>
//     </div>
//   </a>

//   <a href="#" className="list-group-item list-group-item-action mt-5">
//     <div className="d-flex w-100 justify-content-between">
//       <h5 className="mb-1 text-center">Item 4</h5>
//       <small><button className='btn btn-danger'>Delete</button></small>
//     </div>
//     <div className="some">
//         <button className='btn btn-success'>Add</button>
//         <button className='btn btn-dark ms-2'>Update</button>
//         <button className='btn btn-info ms-2'>Read More</button>
//     </div>
//   </a>


//   <a href="#" className="list-group-item list-group-item-action mt-5">
//     <div className="d-flex w-100 justify-content-between text-center">
//       <h5 className="mb-1 "style={{textAlign:"center"}}>Item 5</h5>
//       <small><button className='btn btn-danger'>Delete</button></small>
//     </div>
//     <div className="some">
//         <button className='btn btn-success'>Add</button>
//         <button className='btn btn-dark ms-2'>Update</button>
//         <button className='btn btn-info ms-2'>Read More</button>
//     </div>
//   </a>
//     </div>


//     </>
//   )
// }

// export default StockPage